import { CalorieTracker } from "@/components/CalorieTracker";
import { MoodTracker } from "@/components/MoodTracker";
import { SongOfTheDay } from "@/components/SongOfTheDay";
import { BMICalculator } from "@/components/BMICalculator";
import { StepsTracker } from "@/components/StepsTracker";
import { Star } from "lucide-react";
import { useState } from "react";
import bgImage from "@assets/stock_images/baby_blue_winter_aes_05a78fde.jpg";

export default function Home() {
  const [isPerfectBlue, setIsPerfectBlue] = useState(false);

  const openAcrossTheUniverse = () => {
    window.open("https://open.spotify.com/search/Across%20The%20Universe%20Beatles", '_blank');
  };

  return (
    <div className={`min-h-screen font-sans selection:text-blue-900 overflow-x-hidden transition-all duration-1000 ${
      isPerfectBlue 
        ? "bg-blue-100/50 selection:bg-blue-300" 
        : "bg-blue-50/50 selection:bg-blue-200"
    }`}>
      {/* Background Texture */}
      <div 
        className="fixed inset-0 opacity-5 pointer-events-none z-0"
        style={{ 
          backgroundImage: `url(${bgImage})`,
          backgroundSize: 'cover',
          backgroundPosition: 'center'
        }}
      />

      {/* Main Content */}
      <div className="relative z-10 max-w-md mx-auto min-h-screen flex flex-col p-6">
        
        {/* Header */}
        <header className="py-8 text-center space-y-2 relative">
            {/* Clickable Star Icon */}
            <button
              onClick={openAcrossTheUniverse}
              className={`absolute -top-2 left-1/2 -translate-x-1/2 hover:scale-110 transition-all duration-300 cursor-pointer ${
                isPerfectBlue
                  ? "text-blue-400 hover:text-blue-600"
                  : "text-blue-200 hover:text-blue-400"
              }`}
              title="Play Across The Universe"
            >
              <Star size={40} fill="currentColor" />
            </button>

            <h1 className={`text-5xl font-serif font-bold tracking-tight pt-4 drop-shadow-sm ${
              isPerfectBlue
                ? "text-blue-900"
                : "text-blue-900"
            }`}>
              {isPerfectBlue ? "Perfect Blue" : "Winter Blue"}
            </h1>
            <p className={`font-serif italic text-lg ${
              isPerfectBlue
                ? "text-blue-500"
                : "text-blue-400"
            }`}>
              {isPerfectBlue ? '"Everything is beautiful now"' : '"Help me if you can, I\'m feeling down"'}
            </p>
        </header>

        {/* Main Tracker */}
        <main className="flex-1 space-y-6 pb-12">
          
          <CalorieTracker />

          <BMICalculator onPerfectBlue={setIsPerfectBlue} />

          <StepsTracker />
          
          <div className={`backdrop-blur-sm p-6 rounded-3xl border flex flex-col items-center justify-center text-center transition-all ${
            isPerfectBlue
              ? "bg-blue-300/30 border-blue-200/50"
              : "bg-blue-200/30 border-blue-100/50"
          }`}>
             <span className={`font-serif text-sm italic ${
               isPerfectBlue ? "text-blue-500" : "text-blue-400"
             }`}>Today is</span>
             <span className={`font-bold text-xl ${
               isPerfectBlue ? "text-blue-900" : "text-blue-900"
             }`}>
                 {new Date().toLocaleDateString('en-US', { weekday: 'long' })}
             </span>
             <span className={`text-sm ${
               isPerfectBlue ? "text-blue-700/60" : "text-blue-800/60"
             }`}>
                 {new Date().toLocaleDateString('en-US', { month: 'long', day: 'numeric' })}
             </span>
          </div>

          <MoodTracker />
          
          <SongOfTheDay />

        </main>

        {/* Footer */}
        <footer className={`text-center py-6 text-xs font-serif italic ${
          isPerfectBlue
            ? "text-blue-400"
            : "text-blue-300"
        }`}>
            Stay warm, darling. <br/>
            And keep your feet on the ground.
        </footer>
      </div>
    </div>
  );
}
