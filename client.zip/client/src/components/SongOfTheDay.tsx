import { useState } from "react";
import { Input } from "@/components/ui/input";
import { Button } from "@/components/ui/button";
import { Music, Play, Plus, Trash2, Disc } from "lucide-react";
import { WalrusModal } from "./WalrusModal";

interface SongEntry {
  id: string;
  title: string;
  date: string;
}

export function SongOfTheDay() {
  const [song, setSong] = useState("");
  const [playlist, setPlaylist] = useState<SongEntry[]>([]);
  const [isWalrusOpen, setIsWalrusOpen] = useState(false);

  const checkWalrus = (value: string) => {
    if (value.toLowerCase().includes("walrus")) {
      setIsWalrusOpen(true);
      return true;
    }
    return false;
  };

  const addSong = () => {
    if (!song.trim()) return;
    
    if (checkWalrus(song)) {
      setSong("");
      return;
    }
    
    const newSong: SongEntry = {
      id: Math.random().toString(36).substr(2, 9),
      title: song,
      date: new Date().toLocaleDateString('en-US', { month: 'short', day: 'numeric' })
    };

    setPlaylist([newSong, ...playlist]);
    setSong("");
  };

  const deleteSong = (id: string) => {
    setPlaylist(playlist.filter(s => s.id !== id));
  };

  const openSpotify = (title: string) => {
    const query = encodeURIComponent(title);
    window.open(`https://open.spotify.com/search/${query}`, '_blank');
  };

  return (
    <div className="bg-white/50 backdrop-blur-sm p-6 rounded-3xl border border-blue-100 shadow-sm space-y-4">
      <WalrusModal open={isWalrusOpen} onOpenChange={setIsWalrusOpen} />

      <div className="flex items-center gap-3">
        <div className="p-2 bg-blue-100 rounded-full text-blue-600">
          <Music size={20} />
        </div>
        <h3 className="font-serif text-xl text-blue-900 font-semibold">Record Player</h3>
      </div>
      
      <div className="relative flex gap-2">
        <Input 
          value={song}
          onChange={(e) => setSong(e.target.value)}
          onKeyDown={(e) => e.key === 'Enter' && addSong()}
          placeholder="What's spinning today?"
          className="pl-4 pr-4 py-6 bg-white/80 border-blue-200 focus:border-blue-400 focus:ring-blue-200 rounded-2xl font-serif text-blue-800 placeholder:text-blue-300/70"
        />
        <Button 
          onClick={addSong}
          disabled={!song.trim()}
          className="h-auto rounded-2xl bg-blue-200 hover:bg-blue-300 text-blue-800"
        >
          <Plus size={20} />
        </Button>
      </div>
      
      {playlist.length > 0 && (
        <div className="mt-4 space-y-3">
           <div className="text-xs font-serif text-blue-400 uppercase tracking-widest mb-2 pl-2">Recently Played</div>
           <div className="space-y-2 max-h-60 overflow-y-auto custom-scrollbar pr-2">
             {playlist.map((entry) => (
               <div key={entry.id} className="group bg-white/60 hover:bg-white/80 p-3 rounded-2xl flex items-center justify-between transition-all border border-transparent hover:border-blue-100">
                 <div className="flex items-center gap-3 overflow-hidden">
                   <div className="w-8 h-8 rounded-full bg-blue-100 flex items-center justify-center flex-shrink-0 group-hover:animate-spin-slow">
                     <Disc size={14} className="text-blue-400" />
                   </div>
                   <div className="flex flex-col min-w-0">
                     <span className="font-serif text-blue-900 truncate text-sm font-medium">{entry.title}</span>
                     <span className="text-xs text-blue-300 italic">{entry.date}</span>
                   </div>
                 </div>
                 
                 <div className="flex items-center gap-1">
                   <Button
                     variant="ghost"
                     size="icon"
                     onClick={() => openSpotify(entry.title)}
                     className="h-8 w-8 text-green-500 hover:text-green-600 hover:bg-green-50 rounded-full"
                     title="Play on Spotify"
                   >
                     <Play size={14} fill="currentColor" />
                   </Button>
                   <Button
                     variant="ghost"
                     size="icon"
                     onClick={() => deleteSong(entry.id)}
                     className="h-8 w-8 text-blue-200 hover:text-red-400 hover:bg-red-50 rounded-full opacity-0 group-hover:opacity-100 transition-opacity"
                   >
                     <Trash2 size={14} />
                   </Button>
                 </div>
               </div>
             ))}
           </div>
        </div>
      )}
    </div>
  );
}
