import { Dialog, DialogContent, DialogHeader, DialogTitle, DialogDescription } from "@/components/ui/dialog";
import { Button } from "@/components/ui/button";
import { HeartCrack, AlertTriangle } from "lucide-react";
import { useState, useEffect } from "react";

interface DisappointedModalProps {
  open: boolean;
  onOpenChange: (open: boolean) => void;
  type?: "calorie" | "weight" | "steps";
}

const CALORIE_PUNISHMENTS = [
  "Fast for 36 hours. Your body needs to remember discipline.",
  "500 calories total for the next 2 days. That's all.",
  "200 burpees before you eat again.",
  "No food until you've burned 1000 calories exercising.",
  "Spend the next 3 hours doing cardio. Non-stop.",
  "Only ice water for 48 hours. Nothing else touches your lips.",
  "500 push-ups before bed. Every single one counts.",
  "Tomorrow you eat 400 calories maximum. Make it count.",
  "Every calorie over limit = 10 minutes of running. Do the math.",
  "Complete a 90-minute workout before your next meal."
];

const WEIGHT_PUNISHMENTS = [
  "Nothing but water for the next 72 hours. Complete fast.",
  "Run 20 kilometers. Today. No breaks.",
  "5-minute ice bath. Then another 5-minute one after.",
  "1000 crunches, 500 squats, 300 burpees. Tonight.",
  "Sleep naked on the floor for a week. Feel the cold.",
  "No food for 4 days. Just water and black coffee.",
  "2-hour run every single day for the next week.",
  "Complete a 2-hour strength training session immediately.",
  "Exercise until you vomit, then continue for 20 more minutes.",
  "Skip all meals for 5 days. You've earned nothing."
];

const STEP_PUNISHMENTS = [
  "40,000 steps today. Get moving. No rest.",
  "20 miles on foot before you sleep. Non-negotiable.",
  "Run a marathon today. 42 kilometers. Now.",
  "No sitting, no lying down for 18 hours straight.",
  "50,000 steps in the next 48 hours or fast for a week.",
  "Every hour you're awake = 5,000 steps minimum. All week.",
  "Sprint for 30 minutes, walk for 10. Repeat 5 times.",
  "2-hour intense cardio session starting immediately.",
  "Jog in place for 2 hours straight. No stopping.",
  "60,000 steps this week or no food next week."
];

export function DisappointedModal({ open, onOpenChange, type = "calorie" }: DisappointedModalProps) {
  const [punishment, setPunishment] = useState("");

  useEffect(() => {
    if (open) {
      let list = CALORIE_PUNISHMENTS;
      if (type === "weight") list = WEIGHT_PUNISHMENTS;
      if (type === "steps") list = STEP_PUNISHMENTS;
      
      const randomPunishment = list[Math.floor(Math.random() * list.length)];
      setPunishment(randomPunishment);
    }
  }, [open, type]);

  const getTitle = () => {
      if (type === "weight") return "Weight Increase";
      if (type === "steps") return "Laziness Detected";
      return "Limit Exceeded";
  };

  const getDescription = () => {
      if (type === "weight") return "The scale doesn't lie, darling. We have regressed.";
      if (type === "steps") return "We haven't moved enough today. Stagnation is death.";
      return "We've gone a little over our limit, darling. Discipline must be restored.";
  };

  return (
    <Dialog open={open} onOpenChange={onOpenChange}>
      <DialogContent className="sm:max-w-md border-none bg-white/95 backdrop-blur-sm shadow-xl rounded-3xl font-serif text-center p-8">
        <div className="absolute top-0 left-1/2 -translate-x-1/2 -translate-y-1/2 w-24 h-24 rounded-full bg-red-50 border-4 border-white shadow-sm overflow-hidden flex items-center justify-center z-10">
            <HeartCrack className="w-12 h-12 text-red-400" />
        </div>
        
        <DialogHeader className="pt-10 space-y-4">
          <DialogTitle className="text-3xl font-serif text-blue-900 italic flex flex-col items-center gap-2">
            <span>Oh dear...</span>
            <span className="text-sm font-sans font-normal text-blue-400 tracking-widest uppercase">
              {getTitle()}
            </span>
          </DialogTitle>
          <DialogDescription className="text-lg text-blue-800/70 font-sans">
            {getDescription()}
          </DialogDescription>
        </DialogHeader>
        
        <div className="py-6 flex justify-center">
          <div className="bg-red-50 border border-red-100 p-6 rounded-2xl w-full relative overflow-hidden">
             <div className="absolute -right-4 -top-4 text-red-100 transform rotate-12">
                <AlertTriangle size={80} />
             </div>
             <p className="text-red-400 text-xs font-bold uppercase tracking-widest mb-2">Your Punishment</p>
             <p className="text-red-800 font-serif text-xl font-medium italic relative z-10">
               "{punishment}"
             </p>
          </div>
        </div>

        <div className="flex justify-center">
          <Button 
            onClick={() => onOpenChange(false)}
            className="bg-blue-200 hover:bg-blue-300 text-blue-900 rounded-full px-8 font-serif italic"
          >
            I accept my fate
          </Button>
        </div>
      </DialogContent>
    </Dialog>
  );
}
