import { Dialog, DialogContent, DialogHeader, DialogTitle, DialogDescription } from "@/components/ui/dialog";
import { Button } from "@/components/ui/button";
import { Sparkles, Heart, Cloud, Music, Star, Footprints } from "lucide-react";
import whiteBow from "@assets/stock_images/white_ribbon_bow_aes_a0bba5af.jpg";
import { useState, useEffect } from "react";
import confetti from "canvas-confetti";

interface PraiseModalProps {
  open: boolean;
  onOpenChange: (open: boolean) => void;
  type: "bmi_drop" | "calorie_perfect" | "steps_goal" | "steps_perfect" | "bmi_perfect";
}

const BMI_PRAISES = [
  "You're getting lighter, like a cloud floating downstream.",
  "Beautiful discipline. John would be so proud.",
  "Nothing is real, and you are becoming ethereal.",
  "Living is easy with eyes closed, but you are seeing clearly.",
  "A little less of you, a little more perfection.",
  "You are floating above it all.",
  "Light as a feather, pure as snow.",
];

const BMI_PERFECT_PRAISES = [
  "17.2... The perfect blue has arrived. You are transcendent.",
  "Perfection incarnate. The universe bows to your discipline.",
  "You have reached enlightenment. Everything is beautiful now.",
  "This is it. This is everything we dreamed of. You are perfect.",
  "Help me is no longer needed. You are complete.",
  "The Beatles are singing your name. You are eternal.",
  "17.2... You are the definition of beauty. Nothing else matters.",
];

const CALORIE_PRAISES = [
  "Absolute perfection. You are empty and pure.",
  "Starving the body, feeding the soul.",
  "You are in complete control. It's beautiful.",
  "Light, airy, and disciplined. Just like we practiced.",
  "377... a magic number. You are magic.",
  "So little needed, so much gained.",
];

const STEP_PRAISES = [
  "You are walking on air.",
  "Keep moving, keep floating.",
  "Every step takes you further away from heavy things.",
  "Movement is life. You are alive.",
  "You walked through the strawberry fields forever.",
];

const STEP_PERFECT_PRAISES = [
  "18,927 steps... You have reached the summit.",
  "John is watching, and he is smiling.",
  "Perfection achieved. You are unstoppable.",
  "The long and winding road led you here. Perfect.",
  "You've walked across the universe today.",
];

export function PraiseModal({ open, onOpenChange, type }: PraiseModalProps) {
  const [message, setMessage] = useState("");

  useEffect(() => {
    if (open) {
      let list = BMI_PRAISES;
      if (type === "bmi_perfect") list = BMI_PERFECT_PRAISES;
      if (type === "calorie_perfect") list = CALORIE_PRAISES;
      if (type === "steps_goal") list = STEP_PRAISES;
      if (type === "steps_perfect") list = STEP_PERFECT_PRAISES;
      
      const randomMsg = list[Math.floor(Math.random() * list.length)];
      setMessage(randomMsg);
      
      // Trigger confetti
      const duration = 3 * 1000;
      const animationEnd = Date.now() + duration;
      const defaults = { startVelocity: 30, spread: 360, ticks: 60, zIndex: 50 };

      const randomInRange = (min: number, max: number) => Math.random() * (max - min) + min;

      const interval: any = setInterval(function() {
        const timeLeft = animationEnd - Date.now();

        if (timeLeft <= 0) {
          return clearInterval(interval);
        }

        const particleCount = 50 * (timeLeft / duration);
        confetti({ ...defaults, particleCount, origin: { x: randomInRange(0.1, 0.3), y: Math.random() - 0.2 }, colors: ['#1e3a8a', '#3b82f6'] });
        confetti({ ...defaults, particleCount, origin: { x: randomInRange(0.7, 0.9), y: Math.random() - 0.2 }, colors: ['#1e3a8a', '#3b82f6'] });
      }, 250);
      
      return () => clearInterval(interval);
    }
  }, [open, type]);

  const openAcrossTheUniverse = () => {
    window.open("https://open.spotify.com/search/Across%20The%20Universe%20Beatles", '_blank');
  };

  return (
    <Dialog open={open} onOpenChange={onOpenChange}>
      <DialogContent className={`sm:max-w-md border-none backdrop-blur-sm shadow-[0_0_50px_rgba(161,201,241,0.5)] rounded-3xl font-serif text-center p-8 ${
        type === "bmi_perfect" 
          ? "bg-blue-100/95 shadow-[0_0_80px_rgba(30,58,138,0.3)]" 
          : "bg-blue-50/95"
      }`}>
        
        <div className="absolute top-0 left-1/2 -translate-x-1/2 -translate-y-1/2">
           <div className="relative">
              <div className={`absolute inset-0 blur-xl opacity-50 rounded-full ${
                type === "bmi_perfect" ? "bg-blue-300" : "bg-blue-200"
              }`}></div>
              <div className={`w-20 h-20 rounded-full border-4 flex items-center justify-center relative z-10 animate-pulse ${
                type === "bmi_perfect" 
                  ? "bg-white border-blue-400 shadow-[0_0_30px_rgba(59,130,246,0.5)]" 
                  : "bg-white border-blue-100"
              }`}>
                <Sparkles className={type === "bmi_perfect" ? "text-blue-600 w-10 h-10" : "text-blue-300 w-10 h-10"} />
              </div>
           </div>
        </div>
        
        <DialogHeader className="pt-8 space-y-4">
          <DialogTitle className={`text-3xl font-serif italic flex flex-col items-center gap-2 ${
            type === "bmi_perfect" ? "text-blue-900" : "text-blue-900"
          }`}>
            <span className="drop-shadow-sm">
              {type === "bmi_perfect" ? "P E R F E C T  B L U E" : "Wonderful..."}
            </span>
          </DialogTitle>
          <DialogDescription className={`text-lg italic font-sans ${
            type === "bmi_perfect" ? "text-blue-700/80" : "text-blue-800/80"
          }`}>
            "{message}"
          </DialogDescription>
        </DialogHeader>
        
        <div className={`py-4 flex justify-center gap-2 ${
          type === "bmi_perfect" ? "text-blue-500" : "text-blue-200"
        }`}>
           {type.includes("steps") ? <Footprints size={20} /> : <Cloud size={20} />}
           <Music size={20} />
           <button
             onClick={openAcrossTheUniverse}
             className={`hover:scale-110 transition-all cursor-pointer ${
               type === "bmi_perfect" 
                 ? "hover:text-blue-700" 
                 : "hover:text-blue-400"
             }`}
             title="Play Across The Universe"
           >
             <Star size={20} fill="currentColor" />
           </button>
        </div>

        <div className="flex justify-center">
          <Button 
            onClick={() => onOpenChange(false)}
            className={`border rounded-full px-8 font-serif italic shadow-sm transition-all hover:scale-105 ${
              type === "bmi_perfect"
                ? "bg-blue-50 hover:bg-blue-200 text-blue-900 border-blue-300"
                : "bg-white hover:bg-blue-50 text-blue-900 border-blue-100"
            }`}
          >
            I feel fine
          </Button>
        </div>
      </DialogContent>
    </Dialog>
  );
}
