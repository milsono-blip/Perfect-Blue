import { useState, useEffect } from "react";
import { Input } from "@/components/ui/input";
import { Button } from "@/components/ui/button";
import { Footprints, Check, Trash2, History } from "lucide-react";
import { DisappointedModal } from "./DisappointedModal";
import { PraiseModal } from "./PraiseModal";
import { WalrusModal } from "./WalrusModal";
import { cn } from "@/lib/utils";
import { getUserId, saveStepEntry, getStepEntries, deleteStepEntry } from "@/lib/api";
import { groupEntriesByMonthYear } from "@/lib/grouping";
import { StepEntry as DBStepEntry } from "@shared/schema";

interface StepEntry extends DBStepEntry {
  displayDate?: string;
}

export function StepsTracker() {
  const [steps, setSteps] = useState("");
  const [currentSteps, setCurrentSteps] = useState(0);
  const [entries, setEntries] = useState<StepEntry[]>([]);
  const [userId] = useState(() => getUserId());

  useEffect(() => {
    getStepEntries(userId).then((entries: DBStepEntry[]) => {
      setEntries(entries.map(e => ({
        ...e,
        displayDate: new Date(e.date).toLocaleDateString('en-US', { month: 'short', day: 'numeric' })
      })));
    }).catch(() => {});
  }, [userId]);
  
  const [isPunishmentOpen, setIsPunishmentOpen] = useState(false);
  const [praiseType, setPraiseType] = useState<"steps_goal" | "steps_perfect" | null>(null);
  const [isPraiseOpen, setIsPraiseOpen] = useState(false);
  const [isWalrusOpen, setIsWalrusOpen] = useState(false);

  const GOAL = 10000;
  const PERFECT_GOAL = 18927;

  const checkWalrus = (value: string) => {
    if (value.toLowerCase().includes("walrus")) {
      setIsWalrusOpen(true);
      return true;
    }
    return false;
  };

  const handleLogSteps = async () => {
    const val = parseInt(steps);
    if (!val) return;

    if (checkWalrus(steps)) {
      setSteps("");
      return;
    }

    try {
      const saved = await saveStepEntry({
        userId,
        steps: val,
        date: new Date().toISOString().split('T')[0],
      });

      setCurrentSteps(val);
      setSteps("");

      const newEntry: StepEntry = {
        ...saved,
        displayDate: new Date(saved.date).toLocaleDateString('en-US', { month: 'short', day: 'numeric' })
      };

      setEntries([newEntry, ...entries]);

      if (val < GOAL) {
        setIsPunishmentOpen(true);
      } else if (val >= PERFECT_GOAL) {
        setPraiseType("steps_perfect");
        setIsPraiseOpen(true);
      } else if (val >= GOAL) {
        setPraiseType("steps_goal");
        setIsPraiseOpen(true);
      }
    } catch (error) {
      console.error("Failed to save step entry");
    }
  };

  const deleteEntry = async (id: string) => {
    try {
      await deleteStepEntry(id);
      setEntries(entries.filter(e => e.id !== id));
    } catch (error) {
      console.error("Failed to delete step entry");
    }
  };

  return (
    <div className="space-y-6">
      <DisappointedModal open={isPunishmentOpen} onOpenChange={setIsPunishmentOpen} type="steps" />
      {praiseType && (
        <PraiseModal open={isPraiseOpen} onOpenChange={setIsPraiseOpen} type={praiseType} />
      )}
      <WalrusModal open={isWalrusOpen} onOpenChange={setIsWalrusOpen} />

      <div className="bg-white/50 backdrop-blur-sm p-6 rounded-3xl border border-blue-100 shadow-sm space-y-4">
        <div className="flex items-center gap-3">
          <div className="p-2 bg-blue-100 rounded-full text-blue-600">
            <Footprints size={20} />
          </div>
          <h3 className="font-serif text-xl text-blue-900 font-semibold">Daily Steps</h3>
        </div>

        <div className="relative pt-2">
            <div className="flex items-center justify-between mb-2 text-xs font-serif text-blue-400 uppercase tracking-widest">
               <span>0</span>
               <span>Goal: {GOAL.toLocaleString()}</span>
               <span>Perfect: {PERFECT_GOAL.toLocaleString()}</span>
            </div>
            
            <div className="h-3 bg-blue-50 rounded-full overflow-hidden mb-4">
               <div 
                 className={cn(
                   "h-full rounded-full transition-all duration-1000 ease-out",
                   currentSteps >= PERFECT_GOAL ? "bg-gradient-to-r from-blue-300 via-blue-200 to-white animate-pulse" : 
                   currentSteps >= GOAL ? "bg-blue-300" : "bg-blue-200"
                 )}
                 style={{ width: `${Math.min((currentSteps / PERFECT_GOAL) * 100, 100)}%` }}
               />
            </div>

            {currentSteps > 0 && (
               <div className="text-center mb-4">
                  <span className="text-3xl font-serif font-bold text-blue-900">{currentSteps.toLocaleString()}</span>
                  <span className="text-blue-400 text-sm ml-1 font-medium">steps</span>
               </div>
            )}

            <div className="flex gap-2">
              <Input 
                type="number"
                value={steps}
                onChange={(e) => setSteps(e.target.value)}
                onKeyDown={(e) => e.key === 'Enter' && handleLogSteps()}
                placeholder="Log your steps..."
                className="bg-white/80 border-blue-200 focus:border-blue-400 focus:ring-blue-200 rounded-2xl font-serif text-blue-800 placeholder:text-blue-300/70"
              />
              <Button 
                onClick={handleLogSteps}
                disabled={!steps}
                className="rounded-2xl bg-blue-200 hover:bg-blue-300 text-blue-800 shadow-sm"
              >
                <Check size={20} />
              </Button>
            </div>
        </div>
      </div>

      {/* History Log - Grouped by Month/Year */}
      {entries.length > 0 && (
        <div className="bg-white/40 backdrop-blur-sm p-6 rounded-3xl border border-blue-50 shadow-sm">
           <div className="flex items-center gap-2 mb-4 text-blue-900/70">
              <History size={16} />
              <h4 className="font-serif font-medium">History</h4>
           </div>
           <div className="space-y-4 max-h-96 overflow-y-auto custom-scrollbar pr-2">
              {Array.from(groupEntriesByMonthYear(entries).entries()).map(([monthYear, monthEntries]) => (
                <div key={monthYear}>
                  <h5 className="font-serif text-blue-500 font-semibold text-sm mb-2 uppercase tracking-wider">{monthYear}</h5>
                  <div className="space-y-2">
                    {monthEntries.map((entry) => (
                      <div key={entry.id} className="group flex items-center justify-between p-3 bg-white/60 rounded-2xl border border-transparent hover:border-blue-100 transition-all">
                          <div className="flex flex-col">
                             <span className="text-xs text-blue-400 font-serif italic">{entry.displayDate}</span>
                             <span className="text-blue-900 font-medium text-sm">{entry.steps.toLocaleString()}</span>
                          </div>
                          <button 
                             onClick={() => deleteEntry(entry.id)}
                             className="p-1.5 text-blue-200 hover:text-red-300 hover:bg-red-50 rounded-full transition-colors opacity-0 group-hover:opacity-100"
                          >
                             <Trash2 size={14} />
                          </button>
                      </div>
                    ))}
                  </div>
                </div>
              ))}
           </div>
        </div>
      )}
    </div>
  );
}
