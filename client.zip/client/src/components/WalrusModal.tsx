import { Dialog, DialogContent } from "@/components/ui/dialog";
import { Button } from "@/components/ui/button";
import walrusGif from "@/assets/walrus.gif";

interface WalrusModalProps {
  open: boolean;
  onOpenChange: (open: boolean) => void;
}

export function WalrusModal({ open, onOpenChange }: WalrusModalProps) {
  return (
    <Dialog open={open} onOpenChange={onOpenChange}>
      <DialogContent className="sm:max-w-md border-none bg-blue-50/95 backdrop-blur-sm shadow-xl rounded-3xl font-serif text-center p-8">
        <div className="mb-8 flex justify-center">
          <img 
            src={walrusGif} 
            alt="Walrus" 
            className="w-40 h-40 object-contain"
          />
        </div>
        
        <h2 className="text-4xl font-serif font-bold text-blue-900 mb-4">
          Goo Goo G'joob!
        </h2>
        
        <p className="text-lg text-blue-800/70 font-sans mb-6">
          Oh darling, that's quite the curious entry... but that's not what we're tracking here, sweetie.
        </p>

        <p className="text-sm text-blue-600/60 font-serif italic mb-6">
          (Back to discipline, yes? No walruses allowed. Only vegetables for you.)
        </p>

        <div className="flex justify-center">
          <Button 
            onClick={() => onOpenChange(false)}
            className="bg-blue-200 hover:bg-blue-300 text-blue-900 rounded-full px-8 font-serif italic"
          >
            I understand
          </Button>
        </div>
      </DialogContent>
    </Dialog>
  );
}
