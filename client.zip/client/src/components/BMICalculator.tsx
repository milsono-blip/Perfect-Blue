import { useState, useEffect } from "react";
import { Input } from "@/components/ui/input";
import { Button } from "@/components/ui/button";
import { cn } from "@/lib/utils";
import { Sparkles, Trophy, TrendingUp, TrendingDown, Plus, History, Trash2 } from "lucide-react";
import { Dialog, DialogContent } from "@/components/ui/dialog";
import confetti from "canvas-confetti";
import { DisappointedModal } from "./DisappointedModal";
import { PraiseModal } from "./PraiseModal";
import { WalrusModal } from "./WalrusModal";
import { getUserId, saveWeightEntry, getWeightEntries, deleteWeightEntry } from "@/lib/api";
import { groupEntriesByMonthYear } from "@/lib/grouping";
import { WeightEntry } from "@shared/schema";

interface BMIEntry extends WeightEntry {
  bmi: number;
  displayDate?: string;
}

interface BMICalculatorProps {
  onPerfectBlue?: (isPerfect: boolean) => void;
}

export function BMICalculator({ onPerfectBlue }: BMICalculatorProps) {
  const [weight, setWeight] = useState("");
  const [height, setHeight] = useState("");
  const [entries, setEntries] = useState<BMIEntry[]>([]);
  const [userId] = useState(() => getUserId());

  useEffect(() => {
    getWeightEntries(userId).then((entries: WeightEntry[]) => {
      setEntries(entries.map(e => ({
        ...e,
        bmi: calculateBMI(e.weight, height ? parseFloat(height) : 0),
        displayDate: new Date(e.date).toLocaleDateString('en-US', { month: 'short', day: 'numeric' })
      })));
    }).catch(() => {});
  }, [userId]);
  
  const [showReward, setShowReward] = useState(false);
  const [showPraise, setShowPraise] = useState(false);
  const [showPerfectBlue, setShowPerfectBlue] = useState(false);
  const [isPunishmentOpen, setIsPunishmentOpen] = useState(false);
  const [isWalrusOpen, setIsWalrusOpen] = useState(false);

  const calculateBMI = (w: number, h: number) => {
    if (w > 0 && h > 0) {
      // Convert pounds to kg and inches to meters
      const weightKg = w * 0.453592;
      const heightMeters = h * 0.0254;
      return parseFloat((weightKg / (heightMeters * heightMeters)).toFixed(1));
    }
    return 0;
  };

  const checkWalrus = (value: string) => {
    if (value.toLowerCase().includes("walrus")) {
      setIsWalrusOpen(true);
      return true;
    }
    return false;
  };

  const handleAddEntry = async () => {
    const w = parseFloat(weight);
    const h = parseFloat(height);
    
    if (checkWalrus(weight) || checkWalrus(height)) {
      setWeight("");
      setHeight("");
      return;
    }

    if (!w || !h) return;
    
    try {
      const saved = await saveWeightEntry({
        userId,
        weight: w,
        date: new Date().toISOString().split('T')[0],
      });

      const currentBMI = calculateBMI(w, h);
      const lastEntry = entries[0];

      if (lastEntry) {
        if (currentBMI > lastEntry.bmi) {
           setIsPunishmentOpen(true);
        } else if (currentBMI < lastEntry.bmi) {
           setShowPraise(true);
        }
      }

      // Check for Perfect Blue (17.2)
      if (Math.abs(currentBMI - 17.2) <= 0.2) {
          setShowPerfectBlue(true);
          onPerfectBlue?.(true);
          confetti({
            particleCount: 150,
            spread: 90,
            origin: { y: 0.6 },
            colors: ['#1e3a8a', '#3b82f6', '#F8FAFC']
          });
      }

      if (Math.abs(currentBMI - 18.7) <= 0.5) {
          setShowReward(true);
          confetti({
            particleCount: 100,
            spread: 70,
            origin: { y: 0.6 },
            colors: ['#A1C9F1', '#F8FAFC', '#E0F2FE']
          });
      }

      const newEntry: BMIEntry = {
        ...saved,
        bmi: currentBMI,
        displayDate: new Date(saved.date).toLocaleDateString('en-US', { month: 'short', day: 'numeric' })
      };

      setEntries([newEntry, ...entries]);
      setWeight(""); 
    } catch (error) {
      console.error("Failed to save weight entry");
    }
  };

  const handleDeleteEntry = async (id: string) => {
    try {
      await deleteWeightEntry(id);
      setEntries(entries.filter(e => e.id !== id));
    } catch (error) {
      console.error("Failed to delete weight entry");
    }
  };

  const currentBMI = (weight && height) ? calculateBMI(parseFloat(weight), parseFloat(height)) : 0;

  return (
    <div className="space-y-6">
      <DisappointedModal 
        open={isPunishmentOpen} 
        onOpenChange={setIsPunishmentOpen} 
        type="weight"
      />
      
      <PraiseModal 
        open={showPraise}
        onOpenChange={setShowPraise}
        type="bmi_drop"
      />

      <PraiseModal 
        open={showPerfectBlue}
        onOpenChange={setShowPerfectBlue}
        type="bmi_perfect"
      />

      <WalrusModal open={isWalrusOpen} onOpenChange={setIsWalrusOpen} />
      
      <div className="bg-white/50 backdrop-blur-sm p-6 rounded-3xl border border-blue-100 shadow-sm space-y-4">
        <div className="flex items-center justify-between">
          <h3 className="font-serif text-lg text-blue-900 font-semibold">Body Mass Index</h3>
          {currentBMI > 0 && (
            <div className={`px-3 py-1 rounded-full ${
              Math.abs(currentBMI - 17.2) <= 0.2 
                ? "bg-blue-200" 
                : "bg-blue-100"
            }`}>
               <span className={`font-serif font-bold ${
                 Math.abs(currentBMI - 17.2) <= 0.2 
                   ? "text-blue-800" 
                   : "text-blue-600"
               }`}>
                 {currentBMI}
               </span>
            </div>
          )}
        </div>

        <div className="grid grid-cols-2 gap-4">
          <div className="bg-white/60 p-3 rounded-2xl border border-blue-50">
            <label className="text-xs text-blue-400 font-medium uppercase mb-1 block">Weight (lb)</label>
            <Input 
              value={weight}
              onChange={(e) => setWeight(e.target.value)}
              className="w-full text-center text-xl font-serif border-none bg-transparent focus:ring-0 p-0 text-blue-600 placeholder:text-blue-200"
              placeholder="0.0"
              type="number"
            />
          </div>
          <div className="bg-white/60 p-3 rounded-2xl border border-blue-50">
            <label className="text-xs text-blue-400 font-medium uppercase mb-1 block">Height (in)</label>
            <Input 
              value={height}
              onChange={(e) => setHeight(e.target.value)}
              className="w-full text-center text-xl font-serif border-none bg-transparent focus:ring-0 p-0 text-blue-600 placeholder:text-blue-200"
              placeholder="0"
              type="number"
            />
          </div>
        </div>
        
        <Button 
            onClick={handleAddEntry}
            disabled={!weight || !height}
            className="w-full rounded-2xl bg-blue-200 hover:bg-blue-300 text-blue-800 shadow-sm font-serif italic"
        >
            <Plus size={16} className="mr-2" />
            Log Entry
        </Button>
      </div>

      {/* History Log - Grouped by Month/Year */}
      {entries.length > 0 && (
        <div className="bg-white/40 backdrop-blur-sm p-6 rounded-3xl border border-blue-50 shadow-sm">
           <div className="flex items-center gap-2 mb-4 text-blue-900/70">
              <History size={16} />
              <h4 className="font-serif font-medium">History</h4>
           </div>
           <div className="space-y-4 max-h-96 overflow-y-auto custom-scrollbar pr-2">
              {Array.from(groupEntriesByMonthYear(entries).entries()).map(([monthYear, monthEntries]) => (
                <div key={monthYear}>
                  <h5 className="font-serif text-blue-500 font-semibold text-sm mb-2 uppercase tracking-wider">{monthYear}</h5>
                  <div className="space-y-2">
                    {monthEntries.map((entry, index) => {
                       const prevEntry = monthEntries[index + 1];
                       const isImprovement = prevEntry ? entry.bmi < prevEntry.bmi : true;
                       const isWorse = prevEntry ? entry.bmi > prevEntry.bmi : false;

                       return (
                          <div key={entry.id} className="group flex items-center justify-between p-3 bg-white/60 rounded-2xl border border-transparent hover:border-blue-100 transition-all">
                              <div className="flex flex-col">
                                 <span className="text-xs text-blue-400 font-serif italic">{entry.displayDate}</span>
                                 <span className="text-blue-900 font-medium text-sm">{entry.weight} lb</span>
                              </div>
                              <div className="flex items-center gap-3">
                                 {prevEntry && (
                                    <div className={cn("text-xs", isImprovement ? "text-green-400" : isWorse ? "text-red-400" : "text-gray-400")}>
                                       {isImprovement && <TrendingDown size={14} />}
                                       {isWorse && <TrendingUp size={14} />}
                                    </div>
                                 )}
                                 <div className={`px-2 py-1 rounded-lg min-w-[3rem] text-center ${
                                   Math.abs(entry.bmi - 17.2) <= 0.2
                                     ? "bg-blue-200"
                                     : "bg-blue-50"
                                 }`}>
                                    <span className={`font-serif font-bold text-sm ${
                                      Math.abs(entry.bmi - 17.2) <= 0.2
                                        ? "text-blue-800"
                                        : "text-blue-600"
                                    }`}>
                                      {entry.bmi}
                                    </span>
                                 </div>
                                 <button 
                                    onClick={() => handleDeleteEntry(entry.id)}
                                    className="p-1.5 text-blue-200 hover:text-red-300 hover:bg-red-50 rounded-full transition-colors opacity-0 group-hover:opacity-100"
                                 >
                                    <Trash2 size={14} />
                                 </button>
                              </div>
                          </div>
                       );
                    })}
                  </div>
                </div>
              ))}
           </div>
        </div>
      )}

      <Dialog open={showReward} onOpenChange={setShowReward}>
        <DialogContent className="border-none bg-gradient-to-b from-blue-50 to-white p-8 rounded-3xl text-center max-w-sm">
           <div className="mx-auto bg-yellow-100 w-16 h-16 rounded-full flex items-center justify-center mb-4 animate-bounce">
              <Trophy className="text-yellow-500 w-8 h-8" />
           </div>
           <h2 className="font-serif text-2xl text-blue-900 font-bold mb-2">Wonderful!</h2>
           <p className="text-blue-600/80 font-sans mb-4">
             You're reaching that iconic 18.7 standard. <br/>
             John would be proud of your discipline.
           </p>
           <div className="flex justify-center gap-1 text-yellow-400">
             <Sparkles size={20} />
             <Sparkles size={20} />
             <Sparkles size={20} />
           </div>
        </DialogContent>
      </Dialog>
    </div>
  );
}
