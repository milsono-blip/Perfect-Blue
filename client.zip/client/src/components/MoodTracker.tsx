import { useState, useEffect } from "react";
import { Cloud, CloudSnow, Sun, CloudLightning, Snowflake, Plus, History, Trash2 } from "lucide-react";
import { Button } from "@/components/ui/button";
import { MoodModal } from "./MoodModal";
import { cn } from "@/lib/utils";
import { getUserId, saveMoodLog, getMoodLogs, deleteMoodLog } from "@/lib/api";
import { groupEntriesByMonthYear } from "@/lib/grouping";
import { MoodLog } from "@shared/schema";

interface MoodEntry extends MoodLog {
  displayDate?: string;
}

const moods = [
  { icon: Sun, label: "Radiant", color: "text-amber-400", bg: "bg-amber-50" },
  { icon: Cloud, label: "Cloudy", color: "text-gray-400", bg: "bg-gray-50" },
  { icon: Snowflake, label: "Cold", color: "text-blue-300", bg: "bg-blue-50" },
  { icon: CloudLightning, label: "Stormy", color: "text-indigo-400", bg: "bg-indigo-50" },
];

export function MoodTracker() {
  const [selectedMood, setSelectedMood] = useState<string | null>(null);
  const [isMoodModalOpen, setIsMoodModalOpen] = useState(false);
  const [entries, setEntries] = useState<MoodEntry[]>([]);
  const [userId] = useState(() => getUserId());

  useEffect(() => {
    getMoodLogs(userId).then((logs: MoodLog[]) => {
      setEntries(logs.map(l => ({
        ...l,
        displayDate: new Date(l.date).toLocaleDateString('en-US', { month: 'short', day: 'numeric' })
      })));
    }).catch(() => {});
  }, [userId]);

  const handleMoodSelect = (moodLabel: string) => {
    setSelectedMood(moodLabel);
    setIsMoodModalOpen(true);
  };

  const handleLogMood = async () => {
    if (!selectedMood) return;

    try {
      const saved = await saveMoodLog({
        userId,
        mood: selectedMood,
        date: new Date().toISOString().split('T')[0],
      });
      
      const newEntry: MoodEntry = {
        ...saved,
        displayDate: new Date(saved.date).toLocaleDateString('en-US', { month: 'short', day: 'numeric' })
      };

      setEntries([newEntry, ...entries]);
      setIsMoodModalOpen(false);
    } catch (error) {
      console.error("Failed to save mood log");
    }
  };

  const deleteMood = async (id: string) => {
    try {
      await deleteMoodLog(id);
      setEntries(entries.filter(e => e.id !== id));
    } catch (error) {
      console.error("Failed to delete mood log");
    }
  };

  const getMoodIcon = (moodLabel: string) => {
    const moodData = moods.find(m => m.label === moodLabel);
    return moodData;
  };

  return (
    <div className="space-y-6">
      <MoodModal 
        open={isMoodModalOpen} 
        onOpenChange={setIsMoodModalOpen} 
        mood={selectedMood}
      />

      <div className="bg-white/50 backdrop-blur-sm p-6 rounded-3xl border border-blue-100 shadow-sm">
        <h3 className="font-serif text-xl text-blue-900 font-semibold mb-6 flex items-center gap-2">
          <CloudSnow className="text-blue-400" size={20}/>
          Mood of the Day
        </h3>
        
        <div className="grid grid-cols-4 gap-2 mb-4">
          {moods.map((mood) => {
            const Icon = mood.icon;
            const isSelected = selectedMood === mood.label;
            
            return (
              <button
                key={mood.label}
                onClick={() => handleMoodSelect(mood.label)}
                className={cn(
                  "flex flex-col items-center gap-2 p-3 rounded-2xl transition-all duration-300",
                  isSelected 
                    ? "bg-white shadow-md scale-105 ring-2 ring-blue-100" 
                    : "hover:bg-white/60 hover:scale-105"
                )}
              >
                <div className={cn("p-2 rounded-full transition-colors", mood.bg)}>
                  <Icon className={cn("w-6 h-6", mood.color)} />
                </div>
                <span className={cn(
                  "text-xs font-medium font-sans",
                  isSelected ? "text-blue-900" : "text-blue-900/50"
                )}>
                  {mood.label}
                </span>
              </button>
            );
          })}
        </div>

        {selectedMood && (
          <Button 
            onClick={handleLogMood}
            className="w-full rounded-2xl bg-blue-200 hover:bg-blue-300 text-blue-800 font-serif italic"
          >
            <Plus size={16} className="mr-2" />
            Log {selectedMood} Mood
          </Button>
        )}
      </div>

      {/* Mood History Log - Grouped by Month/Year */}
      {entries.length > 0 && (
        <div className="bg-white/40 backdrop-blur-sm p-6 rounded-3xl border border-blue-50 shadow-sm">
           <div className="flex items-center gap-2 mb-4 text-blue-900/70">
              <History size={16} />
              <h4 className="font-serif font-medium">Mood History</h4>
           </div>
           <div className="space-y-4 max-h-96 overflow-y-auto custom-scrollbar pr-2">
              {Array.from(groupEntriesByMonthYear(entries).entries()).map(([monthYear, monthEntries]) => (
                <div key={monthYear}>
                  <h5 className="font-serif text-blue-500 font-semibold text-sm mb-2 uppercase tracking-wider">{monthYear}</h5>
                  <div className="space-y-2">
                    {monthEntries.map((entry) => {
                       const moodData = getMoodIcon(entry.mood);
                       const Icon = moodData?.icon;

                       return (
                          <div key={entry.id} className="group flex items-center justify-between p-3 bg-white/60 rounded-2xl border border-transparent hover:border-blue-100 transition-all">
                              <div className="flex items-center gap-3">
                                 {Icon && (
                                    <div className={cn("p-2 rounded-full", moodData?.bg)}>
                                       <Icon className={cn("w-4 h-4", moodData?.color)} />
                                    </div>
                                 )}
                                 <div className="flex flex-col">
                                    <span className="text-blue-900 font-medium text-sm">{entry.mood}</span>
                                    <span className="text-xs text-blue-400 font-serif italic">{entry.displayDate}</span>
                                 </div>
                              </div>
                              <button 
                                 onClick={() => deleteMood(entry.id)}
                                 className="p-1.5 text-blue-200 hover:text-red-300 hover:bg-red-50 rounded-full transition-colors opacity-0 group-hover:opacity-100"
                              >
                                 <Trash2 size={14} />
                              </button>
                          </div>
                       );
                    })}
                  </div>
                </div>
              ))}
           </div>
        </div>
      )}
    </div>
  );
}
