import { useState, useEffect } from "react";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Plus, Trash2, Sparkles } from "lucide-react";
import { Progress } from "@/components/ui/progress";
import { DisappointedModal } from "./DisappointedModal";
import { PraiseModal } from "./PraiseModal";
import { WalrusModal } from "./WalrusModal";
import { cn } from "@/lib/utils";
import { getUserId, saveCalorieEntry, getCalorieEntries, deleteCalorieEntry } from "@/lib/api";
import { groupEntriesByMonthYear } from "@/lib/grouping";
import { CalorieEntry } from "@shared/schema";

interface FoodItem extends CalorieEntry {
  timestamp?: string;
}

export function CalorieTracker() {
  const [items, setItems] = useState<FoodItem[]>([]);
  const [calories, setCalories] = useState("");
  const [isModalOpen, setIsModalOpen] = useState(false);
  const [isPraiseOpen, setIsPraiseOpen] = useState(false);
  const [isWalrusOpen, setIsWalrusOpen] = useState(false);
  const [userId] = useState(() => getUserId());

  useEffect(() => {
    // Load entries from database on mount
    getCalorieEntries(userId).then((entries: CalorieEntry[]) => {
      setItems(entries.map(e => ({
        ...e,
        timestamp: new Date(e.date).toLocaleDateString('en-US', { month: 'short', day: 'numeric' })
      })));
    }).catch(() => {
      // If API fails, just use empty state
    });
  }, [userId]);

  const totalCalories = items.reduce((sum, item) => sum + item.calories, 0);
  const LIMIT = 900;
  
  // Check if over limit
  const isOverLimit = totalCalories > LIMIT;

  const getStatusMessage = (total: number) => {
    if (total <= 377) return "Perfection. You are light as air.";
    if (total <= 600) return "Doing well, darling. Stay light.";
    if (total <= 800) return "Careful now. Discipline is beautiful.";
    if (total <= 900) return "You are at the edge.";
    return "Discipline has been lost.";
  };

  const checkWalrus = (value: string) => {
    if (value.toLowerCase().includes("walrus")) {
      setIsWalrusOpen(true);
      return true;
    }
    return false;
  };

  const addItem = async () => {
    if (!calories) return;
    
    if (checkWalrus(calories)) {
      setCalories("");
      return;
    }

    const cal = parseInt(calories);
    
    const newTotal = totalCalories + cal;
    
    if (newTotal > LIMIT && !isOverLimit) {
      // Trigger modal first time crossing limit
      setIsModalOpen(true);
    }
    
    try {
      const saved = await saveCalorieEntry({
        userId,
        calories: cal,
        date: new Date().toISOString().split('T')[0],
      });
      
      const newItem = {
        ...saved,
        timestamp: new Date(saved.date).toLocaleDateString('en-US', { month: 'short', day: 'numeric' })
      };
      
      setItems([newItem, ...items]);
      setCalories("");
    } catch (error) {
      console.error("Failed to save calorie entry");
    }
  };

  const removeItem = async (id: string) => {
    try {
      await deleteCalorieEntry(id);
      setItems(items.filter(i => i.id !== id));
    } catch (error) {
      console.error("Failed to delete calorie entry");
    }
  };

  return (
    <div className="space-y-8">
      <DisappointedModal open={isModalOpen} onOpenChange={setIsModalOpen} />
      <PraiseModal open={isPraiseOpen} onOpenChange={setIsPraiseOpen} type="calorie_perfect" />
      <WalrusModal open={isWalrusOpen} onOpenChange={setIsWalrusOpen} />
      
      {/* Progress Circle Area */}
      <div className="relative flex flex-col items-center justify-center py-8">
        <div className="relative w-64 h-64 flex items-center justify-center">
           {/* Decorative outer ring */}
           <div className={cn(
             "absolute inset-0 rounded-full border-4 animate-spin-slow-reverse transition-colors duration-500",
             totalCalories <= 377 ? "border-blue-200 shadow-[0_0_30px_rgba(161,201,241,0.4)]" : "border-blue-50"
           )} style={{ borderStyle: 'dashed' }}></div>
           
           {/* Main Circle */}
           <div className={cn(
             "w-56 h-56 rounded-full flex flex-col items-center justify-center transition-all duration-500 relative overflow-hidden",
             isOverLimit ? "bg-red-50 border-4 border-red-100 shadow-none" : "bg-white border-4 border-blue-100 shadow-[0_0_40px_rgba(161,201,241,0.3)]"
           )}>
             {/* Perfection Glow Background */}
             {totalCalories <= 377 && (
               <div className="absolute inset-0 bg-gradient-to-br from-blue-50/50 to-transparent pointer-events-none animate-pulse"></div>
             )}

             <span className={cn("text-5xl font-serif font-bold mb-1 relative z-10", isOverLimit ? "text-red-400" : "text-blue-400")}>
               {totalCalories}
             </span>
             <span className="text-blue-300 text-sm font-medium uppercase tracking-widest relative z-10">kcal</span>
             <div className="w-12 h-1 bg-blue-50 my-3 rounded-full relative z-10"></div>
             <span className="text-blue-900/40 text-xs relative z-10">Limit: {LIMIT}</span>
           </div>
        </div>

        {/* Status Message */}
        <div className="mt-4 text-center">
           <p className={cn(
             "font-serif italic transition-colors duration-300 flex items-center gap-2 justify-center",
             totalCalories <= 377 ? "text-blue-500 font-medium" : "text-blue-300"
           )}>
             {totalCalories <= 377 && <Sparkles size={14} className="animate-spin-slow" />}
             {getStatusMessage(totalCalories)}
             {totalCalories <= 377 && <Sparkles size={14} className="animate-spin-slow" />}
           </p>
           
           {/* Special Reward Button for < 377 */}
           {totalCalories > 0 && totalCalories <= 377 && (
             <button 
               onClick={() => setIsPraiseOpen(true)}
               className="mt-2 text-xs text-blue-300 hover:text-blue-500 underline decoration-blue-200 underline-offset-4 transition-colors"
             >
               Receive Praise
             </button>
           )}
        </div>
      </div>

      {/* Input Area */}
      <div className="bg-white/60 backdrop-blur-md p-6 rounded-3xl shadow-sm border border-blue-100">
        <div className="flex gap-3 mb-4">
          <Input
            type="number"
            placeholder="kcal"
            value={calories}
            onChange={(e) => setCalories(e.target.value)}
            onKeyDown={(e) => e.key === 'Enter' && addItem()}
            className="flex-1 bg-white/80 border-blue-100 rounded-2xl focus:ring-blue-200 font-serif text-lg"
          />
          <Button 
            onClick={addItem}
            disabled={!calories}
            size="icon"
            className="rounded-2xl bg-blue-200 hover:bg-blue-300 text-blue-800 shadow-none w-12 h-12"
          >
            <Plus size={24} />
          </Button>
        </div>

        {/* List Grouped by Month/Year */}
        <div className="space-y-4 max-h-96 overflow-y-auto pr-2 custom-scrollbar">
          {items.length === 0 && (
             <div className="text-center py-8 text-blue-300 italic font-serif">
               Your plate is empty...
             </div>
          )}
          {Array.from(groupEntriesByMonthYear(items).entries()).map(([monthYear, monthItems]) => (
            <div key={monthYear}>
              <h4 className="font-serif text-blue-500 font-semibold text-sm mb-2 uppercase tracking-wider">{monthYear}</h4>
              <div className="space-y-2">
                {monthItems.map((item) => (
                  <div key={item.id} className="group flex items-center justify-between p-3 bg-white/40 hover:bg-white/80 rounded-2xl transition-all duration-300 border border-transparent hover:border-blue-100">
                    <span className="text-blue-900/50 font-medium pl-2 text-sm font-serif italic">{item.timestamp}</span>
                    <div className="flex items-center gap-3">
                      <span className="text-blue-900 font-serif text-lg">{item.calories}</span>
                      <button 
                        onClick={() => removeItem(item.id)}
                        className="p-1.5 text-blue-200 hover:text-red-300 hover:bg-red-50 rounded-full transition-colors"
                      >
                        <Trash2 size={14} />
                      </button>
                    </div>
                  </div>
                ))}
              </div>
            </div>
          ))}
        </div>
      </div>
    </div>
  );
}
