import { Dialog, DialogContent, DialogHeader, DialogTitle, DialogDescription } from "@/components/ui/dialog";
import { Button } from "@/components/ui/button";
import { Music, Heart } from "lucide-react";

interface MoodModalProps {
  open: boolean;
  onOpenChange: (open: boolean) => void;
  mood: string | null;
}

const MOOD_DATA: Record<string, { quote: string; song: string; spotifyQuery: string }> = {
  "Radiant": {
    quote: "You are glowing, darling. Hold onto this light.",
    song: "Beautiful Boy (Darling Boy) - John Lennon",
    spotifyQuery: "Beautiful%20Boy%20Darling%20Boy%20John%20Lennon"
  },
  "Cloudy": {
    quote: "Clouds pass, darling. The sun is still there.",
    song: "Imagine - John Lennon",
    spotifyQuery: "Imagine%20John%20Lennon"
  },
  "Cold": {
    quote: "Cold hearts melt with time. Be gentle with yourself.",
    song: "Two of Us - The Beatles",
    spotifyQuery: "Two%20of%20Us%20Beatles"
  },
  "Stormy": {
    quote: "Even storms pass. You are stronger than you think.",
    song: "Oh My Love - John Lennon",
    spotifyQuery: "Oh%20My%20Love%20John%20Lennon"
  }
};

export function MoodModal({ open, onOpenChange, mood }: MoodModalProps) {
  const data = mood ? MOOD_DATA[mood] : null;

  const openSpotify = () => {
    if (data) {
      window.open(`https://open.spotify.com/search/${data.spotifyQuery}`, '_blank');
    }
  };

  return (
    <Dialog open={open} onOpenChange={onOpenChange}>
      <DialogContent className="sm:max-w-md border-none bg-blue-50/95 backdrop-blur-sm shadow-xl rounded-3xl font-serif text-center p-8">
        <div className="absolute top-0 left-1/2 -translate-x-1/2 -translate-y-1/2">
           <div className="relative">
              <div className="absolute inset-0 bg-blue-200 blur-xl opacity-50 rounded-full"></div>
              <div className="w-16 h-16 rounded-full bg-white border-4 border-blue-100 flex items-center justify-center relative z-10">
                <Heart className="text-blue-300 w-8 h-8" />
              </div>
           </div>
        </div>

        {data && (
          <>
            <DialogHeader className="pt-8 space-y-4">
              <DialogTitle className="text-2xl font-serif text-blue-900 italic">
                {mood}
              </DialogTitle>
              <DialogDescription className="text-lg text-blue-800/80 font-sans italic">
                "{data.quote}"
              </DialogDescription>
            </DialogHeader>

            <div className="py-6 flex justify-center">
              <Button
                onClick={openSpotify}
                className="bg-green-500 hover:bg-green-600 text-white rounded-full px-6 font-serif flex items-center gap-2 shadow-sm"
              >
                <Music size={16} fill="white" />
                Play: {data.song}
              </Button>
            </div>
          </>
        )}

        <div className="flex justify-center">
          <Button 
            onClick={() => onOpenChange(false)}
            className="bg-white hover:bg-blue-50 text-blue-900 border border-blue-100 rounded-full px-8 font-serif italic shadow-sm transition-all hover:scale-105"
          >
            Close
          </Button>
        </div>
      </DialogContent>
    </Dialog>
  );
}
