import { InsertMoodLog, InsertCalorieEntry, InsertWeightEntry, InsertStepEntry } from "@shared/schema";

// Simple userId management - generate one and store in localStorage
export function getUserId(): string {
  let userId = localStorage.getItem("userId");
  if (!userId) {
    userId = Math.random().toString(36).substr(2, 9);
    localStorage.setItem("userId", userId);
  }
  return userId;
}

export async function saveMoodLog(data: InsertMoodLog) {
  const response = await fetch("/api/mood-logs", {
    method: "POST",
    headers: { "Content-Type": "application/json" },
    body: JSON.stringify(data),
  });
  if (!response.ok) throw new Error("Failed to save mood log");
  return response.json();
}

export async function getMoodLogs(userId: string) {
  const response = await fetch(`/api/mood-logs/${userId}`);
  if (!response.ok) throw new Error("Failed to fetch mood logs");
  return response.json();
}

export async function deleteMoodLog(id: string) {
  const response = await fetch(`/api/mood-logs/${id}`, { method: "DELETE" });
  if (!response.ok) throw new Error("Failed to delete mood log");
  return response.json();
}

export async function saveCalorieEntry(data: InsertCalorieEntry) {
  const response = await fetch("/api/calorie-entries", {
    method: "POST",
    headers: { "Content-Type": "application/json" },
    body: JSON.stringify(data),
  });
  if (!response.ok) throw new Error("Failed to save calorie entry");
  return response.json();
}

export async function getCalorieEntries(userId: string) {
  const response = await fetch(`/api/calorie-entries/${userId}`);
  if (!response.ok) throw new Error("Failed to fetch calorie entries");
  return response.json();
}

export async function deleteCalorieEntry(id: string) {
  const response = await fetch(`/api/calorie-entries/${id}`, { method: "DELETE" });
  if (!response.ok) throw new Error("Failed to delete calorie entry");
  return response.json();
}

export async function saveWeightEntry(data: InsertWeightEntry) {
  const response = await fetch("/api/weight-entries", {
    method: "POST",
    headers: { "Content-Type": "application/json" },
    body: JSON.stringify(data),
  });
  if (!response.ok) throw new Error("Failed to save weight entry");
  return response.json();
}

export async function getWeightEntries(userId: string) {
  const response = await fetch(`/api/weight-entries/${userId}`);
  if (!response.ok) throw new Error("Failed to fetch weight entries");
  return response.json();
}

export async function deleteWeightEntry(id: string) {
  const response = await fetch(`/api/weight-entries/${id}`, { method: "DELETE" });
  if (!response.ok) throw new Error("Failed to delete weight entry");
  return response.json();
}

export async function saveStepEntry(data: InsertStepEntry) {
  const response = await fetch("/api/step-entries", {
    method: "POST",
    headers: { "Content-Type": "application/json" },
    body: JSON.stringify(data),
  });
  if (!response.ok) throw new Error("Failed to save step entry");
  return response.json();
}

export async function getStepEntries(userId: string) {
  const response = await fetch(`/api/step-entries/${userId}`);
  if (!response.ok) throw new Error("Failed to fetch step entries");
  return response.json();
}

export async function deleteStepEntry(id: string) {
  const response = await fetch(`/api/step-entries/${id}`, { method: "DELETE" });
  if (!response.ok) throw new Error("Failed to delete step entry");
  return response.json();
}
