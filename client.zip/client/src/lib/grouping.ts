export function groupEntriesByMonthYear<T extends { date: string }>(entries: T[]): Map<string, T[]> {
  const grouped = new Map<string, T[]>();
  
  entries.forEach(entry => {
    const date = new Date(entry.date);
    const monthYear = date.toLocaleDateString('en-US', { year: 'numeric', month: 'long' });
    
    if (!grouped.has(monthYear)) {
      grouped.set(monthYear, []);
    }
    grouped.get(monthYear)!.push(entry);
  });
  
  return grouped;
}

export function getMonthYearLabel(dateString: string): string {
  const date = new Date(dateString);
  return date.toLocaleDateString('en-US', { year: 'numeric', month: 'long' });
}
