import { type User, type InsertUser, type MoodLog, type InsertMoodLog, type CalorieEntry, type InsertCalorieEntry, type WeightEntry, type InsertWeightEntry, type StepEntry, type InsertStepEntry } from "@shared/schema";
import { randomUUID } from "crypto";

export interface IStorage {
  getUser(id: string): Promise<User | undefined>;
  getUserByUsername(username: string): Promise<User | undefined>;
  createUser(user: InsertUser): Promise<User>;
  
  createMoodLog(log: InsertMoodLog): Promise<MoodLog>;
  getMoodLogsByUser(userId: string): Promise<MoodLog[]>;
  deleteMoodLog(id: string): Promise<void>;
  
  createCalorieEntry(entry: InsertCalorieEntry): Promise<CalorieEntry>;
  getCalorieEntriesByUser(userId: string): Promise<CalorieEntry[]>;
  deleteCalorieEntry(id: string): Promise<void>;
  
  createWeightEntry(entry: InsertWeightEntry): Promise<WeightEntry>;
  getWeightEntriesByUser(userId: string): Promise<WeightEntry[]>;
  deleteWeightEntry(id: string): Promise<void>;
  
  createStepEntry(entry: InsertStepEntry): Promise<StepEntry>;
  getStepEntriesByUser(userId: string): Promise<StepEntry[]>;
  deleteStepEntry(id: string): Promise<void>;
}

export class MemStorage implements IStorage {
  private users: Map<string, User> = new Map();
  private moodLogs: Map<string, MoodLog> = new Map();
  private calorieEntries: Map<string, CalorieEntry> = new Map();
  private weightEntries: Map<string, WeightEntry> = new Map();
  private stepEntries: Map<string, StepEntry> = new Map();

  async getUser(id: string): Promise<User | undefined> {
    return this.users.get(id);
  }

  async getUserByUsername(username: string): Promise<User | undefined> {
    return Array.from(this.users.values()).find(u => u.username === username);
  }

  async createUser(insertUser: InsertUser): Promise<User> {
    const user: User = { ...insertUser, id: randomUUID() };
    this.users.set(user.id, user);
    return user;
  }

  async createMoodLog(log: InsertMoodLog): Promise<MoodLog> {
    const entry: MoodLog = { ...log, id: randomUUID(), createdAt: new Date() };
    this.moodLogs.set(entry.id, entry);
    return entry;
  }

  async getMoodLogsByUser(userId: string): Promise<MoodLog[]> {
    return Array.from(this.moodLogs.values()).filter(m => m.userId === userId);
  }

  async deleteMoodLog(id: string): Promise<void> {
    this.moodLogs.delete(id);
  }

  async createCalorieEntry(entry: InsertCalorieEntry): Promise<CalorieEntry> {
    const cal: CalorieEntry = { ...entry, id: randomUUID(), createdAt: new Date() };
    this.calorieEntries.set(cal.id, cal);
    return cal;
  }

  async getCalorieEntriesByUser(userId: string): Promise<CalorieEntry[]> {
    return Array.from(this.calorieEntries.values()).filter(c => c.userId === userId);
  }

  async deleteCalorieEntry(id: string): Promise<void> {
    this.calorieEntries.delete(id);
  }

  async createWeightEntry(entry: InsertWeightEntry): Promise<WeightEntry> {
    const weight: WeightEntry = { ...entry, id: randomUUID(), createdAt: new Date() };
    this.weightEntries.set(weight.id, weight);
    return weight;
  }

  async getWeightEntriesByUser(userId: string): Promise<WeightEntry[]> {
    return Array.from(this.weightEntries.values()).filter(w => w.userId === userId);
  }

  async deleteWeightEntry(id: string): Promise<void> {
    this.weightEntries.delete(id);
  }

  async createStepEntry(entry: InsertStepEntry): Promise<StepEntry> {
    const step: StepEntry = { ...entry, id: randomUUID(), createdAt: new Date() };
    this.stepEntries.set(step.id, step);
    return step;
  }

  async getStepEntriesByUser(userId: string): Promise<StepEntry[]> {
    return Array.from(this.stepEntries.values()).filter(s => s.userId === userId);
  }

  async deleteStepEntry(id: string): Promise<void> {
    this.stepEntries.delete(id);
  }
}

export const storage = new MemStorage();
