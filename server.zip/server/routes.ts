import type { Express } from "express";
import { createServer, type Server } from "http";
import { storage } from "./storage";
import { insertMoodLogSchema, insertCalorieEntrySchema, insertWeightEntrySchema, insertStepEntrySchema } from "@shared/schema";
import { z } from "zod";

export async function registerRoutes(
  httpServer: Server,
  app: Express
): Promise<Server> {
  app.post("/api/mood-logs", async (req, res) => {
    try {
      const parsed = insertMoodLogSchema.parse(req.body);
      const result = await storage.createMoodLog(parsed);
      res.json(result);
    } catch (error) {
      res.status(400).json({ error: "Invalid request" });
    }
  });

  app.get("/api/mood-logs/:userId", async (req, res) => {
    try {
      const logs = await storage.getMoodLogsByUser(req.params.userId);
      res.json(logs);
    } catch (error) {
      res.status(500).json({ error: "Failed to fetch logs" });
    }
  });

  app.delete("/api/mood-logs/:id", async (req, res) => {
    try {
      await storage.deleteMoodLog(req.params.id);
      res.json({ success: true });
    } catch (error) {
      res.status(500).json({ error: "Failed to delete log" });
    }
  });

  app.post("/api/calorie-entries", async (req, res) => {
    try {
      const parsed = insertCalorieEntrySchema.parse(req.body);
      const result = await storage.createCalorieEntry(parsed);
      res.json(result);
    } catch (error) {
      res.status(400).json({ error: "Invalid request" });
    }
  });

  app.get("/api/calorie-entries/:userId", async (req, res) => {
    try {
      const entries = await storage.getCalorieEntriesByUser(req.params.userId);
      res.json(entries);
    } catch (error) {
      res.status(500).json({ error: "Failed to fetch entries" });
    }
  });

  app.delete("/api/calorie-entries/:id", async (req, res) => {
    try {
      await storage.deleteCalorieEntry(req.params.id);
      res.json({ success: true });
    } catch (error) {
      res.status(500).json({ error: "Failed to delete entry" });
    }
  });

  app.post("/api/weight-entries", async (req, res) => {
    try {
      const parsed = insertWeightEntrySchema.parse(req.body);
      const result = await storage.createWeightEntry(parsed);
      res.json(result);
    } catch (error) {
      res.status(400).json({ error: "Invalid request" });
    }
  });

  app.get("/api/weight-entries/:userId", async (req, res) => {
    try {
      const entries = await storage.getWeightEntriesByUser(req.params.userId);
      res.json(entries);
    } catch (error) {
      res.status(500).json({ error: "Failed to fetch entries" });
    }
  });

  app.delete("/api/weight-entries/:id", async (req, res) => {
    try {
      await storage.deleteWeightEntry(req.params.id);
      res.json({ success: true });
    } catch (error) {
      res.status(500).json({ error: "Failed to delete entry" });
    }
  });

  app.post("/api/step-entries", async (req, res) => {
    try {
      const parsed = insertStepEntrySchema.parse(req.body);
      const result = await storage.createStepEntry(parsed);
      res.json(result);
    } catch (error) {
      res.status(400).json({ error: "Invalid request" });
    }
  });

  app.get("/api/step-entries/:userId", async (req, res) => {
    try {
      const entries = await storage.getStepEntriesByUser(req.params.userId);
      res.json(entries);
    } catch (error) {
      res.status(500).json({ error: "Failed to fetch entries" });
    }
  });

  app.delete("/api/step-entries/:id", async (req, res) => {
    try {
      await storage.deleteStepEntry(req.params.id);
      res.json({ success: true });
    } catch (error) {
      res.status(500).json({ error: "Failed to delete entry" });
    }
  });

  return httpServer;
}
